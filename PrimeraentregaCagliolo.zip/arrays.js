class producto {
    constructor (id, tipo, precio) {
        this.id = parseInt(id);
        this.tipo = tipo;
        this.precio = parseInt(precio);
    }
    descuento5unidades() {
        this.precio = this.precio - 400;
    }

    descuentoMuchasUnidades() {
        this.precio = this.precio - 450;
    }

}

const productos = [];
productos.push (new producto("1","color base", "500"));
productos.push (new producto ("2", "lijado y sin pintar", "600"));
productos.push (new producto ("3","Pintado completo", "1000"));

for (const producto of productos) {
    console.log (producto.id);
    console.log (producto.tipo);
    console.log (producto.precio);
}

function solicitarDatos (tipoServicio, cantidadUnidades) {
//     if ((tipoServicio==(productos.id==1)) && (cantidadUnidades<=5)) {
//         console.log("El servicio te vale: " + (producto.precio==1)*cantidadUnidades);
//     } else if ((tipoServicio==(productos.id==1)) && ((cantidadUnidades >=5) && (cantidadUnidades<=50))){
//         console.log("El servicio te vale: " + (producto.precio==1)*cantidadUnidades);
//     } else if ((tipoServicio==(productos.id==1)) && (cantidadUnidades>=50)) {
        
//         console.log ("El servicio te vale: " + (producto.precio==1)*cantidadUnidades);
//     } else if ((tipoServicio==(productos.id==2)) && (cantidadUnidades<=5)) {
//         console.log("El servicio te vale: " + (producto.precio==2)*cantidadUnidades);
//     } else if ((tipoServicio==(productos.id==2)) && ((cantidadUnidades >=5) && (cantidadUnidades<=50))){
        
//         console.log("El servicio te vale: " + (producto.precio==2)*cantidadUnidades);
//     } else if ((tipoServicio==(productos.id==2)) &&  (cantidadUnidades>=50)){
        
//         console.log ("El servicio te vale: " + (producto.precio==2)*cantidadUnidades);
//     } else if ((tipoServicio==(productos.id==3)) && (cantidadUnidades<=5)) {
//         console.log("El servicio te vale: " + (producto.precio==3)*cantidadUnidades);
//     } else if ((tipoServicio==(productos.id==3)) && ((cantidadUnidades >=5) && (cantidadUnidades<=50))){
        
//         console.log("El servicio te vale: " + (producto.precio==3)*cantidadUnidades);
//     } else if ((tipoServicio==(productos.id==3)) && (cantidadUnidades>=50)){
        
//         console.log ("El servicio te vale: " + (producto.precio==3)*cantidadUnidades);
//     } else {
//         console.log("No ingresaste un valor adecuado");
//     }
// }
// }
let busqueda = productos.filter(x => x.id == tipoServicio)[0]
console.log ("El servicio te vale: " + (busqueda.precio*cantidadUnidades))
console.log(busqueda)
}
// let descuento5unidades = producto.descuento5unidades();
// let descuentoMuchasUnidades = producto.descuentoMuchasUnidades();
// if ((cantidadUnidades >=5) && (cantidadUnidades<=50)) {
//     console.log ("El servicio te vale: " + descuento5unidades*cantidadUnidades);

// } else if (cantidadUnidades>=50) {
//     console.log ("El servicio te vale: " + descuentoMuchasUnidades*cantidadUnidades);
// } else {
//     console.log("No ingresaste valor adecuado");
// }

let tipoServicio = parseInt(prompt("Ingresa el tipo de servicio que quiere: 1-Color Base, 2-Lijado y sin pintar, 3-Pintado Completo: "));
let cantidadUnidades =parseInt(prompt("Ingrese la cantidad de unidades que desea: "));
solicitarDatos(tipoServicio, cantidadUnidades);